Abandoned House bot

** Huge credit to Major as I used a lot of his UIB code for utils, potion buying, etc.
** Huge credit to SirOlaf for creating WizSprinter and StarrFox for creating Wizwalker

- HIGHLY suggest running with 4 players to ensure killing boss on second round
- Player 1(top left client) should have the fishy icon on all other players' friends lists
- Make sure to set your configs for mob and boss fights (reference the guide in wizwalker discord)
- All players must have a castle with world gate directly behind them
- Player 1-4 is detected top to bottom, left to right, like all wizwalker bots
- All players must have 7 or less cards in their deck so they pull on first turn
- If you are using mass feint, make sure it's the only feint in your deck
- Try to have a decent amount of gold on all players for potion buying
- Start at the sigil for abandoned house with enough mana to mark locations